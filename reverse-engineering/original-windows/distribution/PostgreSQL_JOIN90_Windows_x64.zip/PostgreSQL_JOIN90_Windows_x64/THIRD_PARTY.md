# Компоненты поставки

- Universal Trainer: исходник закрытого репозитория kryovox/universal-trainer, ядро Mark 1.01.
- PGlite 0.5.17, PostgreSQL 18.7 в WebAssembly. npm-пакет @electric-sql/pglite, Apache-2.0. Полная лицензия находится в runtime/node_modules/@electric-sql/pglite/LICENSE. https://pglite.dev
- Node.js 22.23.5 Windows x64. Полная лицензия и уведомления о компонентах включены в runtime/NODE_LICENSE.txt. https://nodejs.org/dist/v22.23.5/

В runtime/package-lock.json закреплены версия, URL и integrity PGlite. В runtime/NODE_VERSION.txt записаны источник Node и проверенная контрольная сумма ZIP. Студенческая поставка работает локально и использует встроенные компоненты.
